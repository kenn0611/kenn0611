var number = 0;

function writeNumber(){
  document.querySelector("#numbers").innerHTML=number;
}

function addMe(){
  number = number+1;
  
  writeNumber();
}

writeNumber();

